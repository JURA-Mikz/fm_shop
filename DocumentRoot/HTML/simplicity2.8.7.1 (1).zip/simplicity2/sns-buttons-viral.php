<div class="sns-group sns-group-viral">
  <?php get_template_part('sns-buttons-icon'); ?>
</div>