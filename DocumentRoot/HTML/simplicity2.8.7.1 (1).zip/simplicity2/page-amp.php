<?php //AMPヘッダー
get_template_part('amp-header'); ?>

<?php //AMP本文
get_template_part('amp-content'); ?>

<?php //AMPフッター
get_template_part('amp-footer'); ?>