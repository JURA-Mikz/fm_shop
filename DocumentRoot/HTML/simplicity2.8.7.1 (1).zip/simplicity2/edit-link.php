<?php if (is_edit_visible()): ?>
<?php edit_post_link(__( '編集', 'simplicity2' ), '<span class="edit"><span class="fa fa-pencil-square-o fa-fw"></span>', '</span>'); ?>
<?php endif; ?>