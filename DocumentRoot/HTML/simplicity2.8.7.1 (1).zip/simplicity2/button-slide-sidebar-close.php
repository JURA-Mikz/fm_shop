<?php
///////////////////////////////////////
// スライドサイドバー用の閉じるボタン
///////////////////////////////////////
if ( is_mobile_menu_type_slide_in() ): ?>
  <div class="slide-close">
    <a id="footer-button-sidebar-close" href="#navi">
      <div class="menu-icon"><span class="fa fa-times"></span></div>
    </a>
  </div>
<?php endif ?>
